<html>
        
        <head>
            <title>Welcome </title>
        </head>
        <body> 

        
        <form action="../controlador/Co_fecha_ranking.php" method="post">
	
		<div>
        
        <input type="date" name="fechaInicio" > fechaInicio <br>
        <input type="date" name="fechafinal" > fechafinal <br>
         
			
			
			
			
			
		</div>
		<br>

		<div>
			<input type="submit" value="Limpiar la Cesta" name="limpiar">
		</div>		
    </form>
    <a  href="../vista/Vista_menu.php" > volver al menu </a> 
    
    
    <?php
    if(!empty($array)&&isset($array)){
      ver($array);
    }
    
    ?>      
    
      </body>

   </html>
   <?php 

function ver($facturas){
    echo "adhaadhh";
    $array_keys1=array_keys($facturas[0]); 
    echo "<table border='2px'>";
    echo "<tr>";
  for ($i=0; $i<count($array_keys1) ; $i++) 
        echo "<td>".$array_keys1[$i]."</td>";
  echo "</tr>";
    for ($i=0; $i < count($facturas) ; $i++) { 
        $factura=$facturas[$i];
        echo "<tr>";
            foreach ($factura as $key => $value) {
                echo "<td>".$value."</td>";
               
            }
        echo "</tr>";
      
    }

  echo "</table>";
  
  

}
   
   ?>

