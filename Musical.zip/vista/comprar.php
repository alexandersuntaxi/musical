 <html>
        
        <head>
            <title>Welcome </title>
        </head>
        <body> 
        <form action="../controlador/TiendaMusica.php" method="post">
		<h1>productos:</h1>
		<div>
			<select name="musica">
				<?php forEach ($lista_musica as $nombre) : ?>
					<?php echo '<option>'.  $nombre . '</option>'; ?>
				<?php endforEach; ?>
			</select>

			
			
			
			<br>
			<br> 
			
			
			
		</div>
		<br>

		<div>
			<input type="submit" value="Agregar a la Cesta" name="agregar">
            <input type="submit" value="finalizar compra" name="compra">
			<input type="submit" value="Limpiar la Cesta" name="limpiar">
		</div>		
	</form>  
	<a  href="../vista/Vista_menu.php" > volver al menu </a> 
    
      </body>

   </html>
