<html>
        
        <head>
            <title>Welcome </title>
        </head>
        <body> 
      
		<a href="../controlador/TiendaMusica.php"> <button >tienda musica</button> </a> 	
      
        <a href="../controlador/Co_historico.php"> <button >ver historial</button> </a> 
        <a href="../controlador/Co_fecha.php"> <button >ver canciones fecha </button> </a> 
		<a href="../controlador/Co_fecha_ranking.php"> <button >ver ranking </button> </a> 
      </body>
      <a  href="../vista/Vista_menu.php" > volver al menu </a> 
    
    
   </html>
