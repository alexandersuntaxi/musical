
<?php
  
  session_start();
  var_dump($_SESSION);
require_once('../db/config.php');
var_dump($_POST);
require_once('../modelo/Mo_consulta_fecha.php');
$array=consultaHistorica($db);

require_once('../vista/Vista_fecha.php');


?>