
<?php
  
  session_start();
  var_dump($_SESSION);
require_once('../db/config.php');

require_once('../modelo/Mo_consulta_historica.php');
$array=consultaHistorica($db);

require_once('../vista/Vista_consultahistorica.php');


?>