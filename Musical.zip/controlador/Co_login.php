<?php
  
  session_start();
  var_dump($_SESSION);
require_once('../db/config.php');

require_once('../modelo/Mo_login.php');

require_once('../vista/login.php');


?>