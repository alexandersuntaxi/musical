<?php 
  
 

require_once('../db/config.php');
require_once('../modelo/Mo_carrito.php');
$lista_musica=musicas($db);
require_once('../vista/comprar.php');


?>