<?php
   
 //session_start();
 var_dump($_SESSION);
   
   
  $error="";
   if($_SERVER["REQUEST_METHOD"] == "POST") {
     
   $myusername = mysqli_real_escape_string($db,$_POST['username']);
      $mypassword = mysqli_real_escape_string($db,$_POST['password']); 
      
      $sql = "SELECT CustomerID FROM Customer WHERE email = '$myusername' and lastName = '$mypassword'";//aqui comprobamos si existe el 
     
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      
      
      $count = mysqli_num_rows($result);
      
   	
      if($count == 1) {
         
         $_SESSION['login_user'] = $myusername;
         $_SESSION['id_usuario']=$row['CustomerID'];
         header("Location:../vista/Vista_menu.php");

      }else {
      $error = "Your Login Name or Password is invalid";
        
      }
   }

   ?>