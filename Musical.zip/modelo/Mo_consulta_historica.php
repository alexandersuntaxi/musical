<?php
function consultaHistorica($db){
    $factura=null;
    

       echo $sql="select distinct invoice.* from Customer,invoice,invoiceLine where Customer.customerID=invoice.customerID and invoice.invoiceId=invoiceLine.invoiceId and Customer.customerID=1";
        
    $resultado = mysqli_query($db, $sql);
        if($resultado){
            while ($fila = mysqli_fetch_assoc($resultado)) {
            
                $factura[] =$fila;

                
                
            }
        }
       
    
    
    
   
return $factura;
}
?>