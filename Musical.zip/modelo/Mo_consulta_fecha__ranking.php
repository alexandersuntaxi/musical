<?php
function consultaHistorica($db){
    $factura=null;
    if(isset($_POST['fechaInicio']) && !empty($_POST['fechaInicio']) && isset($_POST['fechafinal']) && !empty($_POST['fechafinal']) ){
       $fechaI=$_POST['fechaInicio'];
 echo "agdga";
       $fechaF=$_POST['fechafinal'];
       echo $sql="select Track.name as nombreCancion,sum(invoiceLine.Quantity) as descargas from Customer,invoice,invoiceLine,Track where invoiceLine.TrackId=Track.TrackId and Customer.customerID=invoice.customerID and invoice.invoiceId=invoiceLine.invoiceId and invoice.invoiceDate BETWEEN '$fechaI' AND '$fechaF'  group by Track.name ORDER BY  sum(invoiceLine.Quantity) DESC";
        
    $resultado = mysqli_query($db, $sql);
        if($resultado){
            while ($fila = mysqli_fetch_assoc($resultado)) {
            
                $factura[] =$fila;

                
                
            }
        }
       
    }
    
    
   
return $factura;
}
?>