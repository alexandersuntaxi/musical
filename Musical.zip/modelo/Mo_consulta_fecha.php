<?php

function consultaHistorica($db){
    $id=$_SESSION['id_usuario'];
    $factura=null;
    if(isset($_POST['fechaInicio']) && !empty($_POST['fechaInicio']) && isset($_POST['fechafinal']) && !empty($_POST['fechafinal']) ){
       $fechaI=$_POST['fechaInicio'];
 echo "agdga";
       $fechaF=$_POST['fechafinal'];
       echo $sql="select distinct invoice.* from Customer,invoice,invoiceLine where Customer.customerID=invoice.customerID and invoice.invoiceId=invoiceLine.invoiceId and Customer.customerID='$id' and invoice.invoiceDate BETWEEN '$fechaI' AND '$fechaF'";
        
    $resultado = mysqli_query($db, $sql);
        if($resultado){
            while ($fila = mysqli_fetch_assoc($resultado)) {
            
                $factura[] =$fila;

                
                
            }
        }
       
    }
    
    
   
return $factura;
}
?>