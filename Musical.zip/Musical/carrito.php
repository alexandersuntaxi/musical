 <?php
   session_start();
   include('config.php');
    $GLOBALS['conexion']=$db; 
   $lista_musica=musicas($db);
   var_dump($_POST);
    if(isset($_POST['agregar'])){
       
        agregarcancion($db);

    }elseif (isset($_POST['compra'])) {
     comprar($db);
        
    }else if(isset($_POST['limpiar'])){
     $_SESSION['carrito3']=null;

    }

   ?>
    <html>
        
        <head>
            <title>Welcome </title>
        </head>
        <body> 
        <form action="#" method="post">
		<h1>productos:</h1>
		<div>
			<select name="musica">
				<?php forEach ($lista_musica as $nombre) : ?>
					<?php echo '<option>'.  $nombre . '</option>'; ?>
				<?php endforEach; ?>
			</select>

			
			
			
			<br>
			<br> 
			
			
			
		</div>
		<br>

		<div>
			<input type="submit" value="Agregar a la Cesta" name="agregar">
            <input type="submit" value="finalizar compra" name="compra">
			<input type="submit" value="Limpiar la Cesta" name="limpiar">
		</div>		
	</form>      
    
      </body>

   </html>

   <?php 

function comprar($db){
    $precioTotal=0;
    $arrayAsocitivoCompra=$_SESSION['carrito3'];
    crearFactura($db);
    
      
}
function crearFactura($db){

    $precioTotal=preciototal($db);
    $id_customer=4;
    $invoiceDate=date('now');
    $idFactura=crearIDFactura($db);
    $sql = " INSERT INTO `Invoice` (`InvoiceId`, `CustomerId`, `InvoiceDate`, `BillingAddress`, `BillingCity`, `BillingCountry`, `BillingPostalCode`, `Total`) VALUES ()";
   
   


}

function crearIDFactura($db){
    $sql ="select max(InvoiceId) as codigoFactura  from Invoice";
    $resultado = mysqli_query($db, $sql);
    if($resultado){
        $fila = mysqli_fetch_assoc($resultado);
       $codigoInvoice= $fila['codigoFactura'];
    }
    
return $codigoInvoice++;
    

}
function crearFacturaLinea(){

    $sql = "INSERT INTO  (ID_PRODUCTO, NOMBRE,PRECIO,ID_CATEGORIA) ";
 
    
 
 }
function preciototal($db){
    $arrayAsocitivoCompra=$_SESSION['carrito3'];
    foreach ($arrayAsocitivoCompra as $key => $value) {
        $array=$value;
        $precioTotal+=(cogerPrecioIndividual($value[0],$db))*$value[1];
     
       
    }
    return $precioTotal;
}
function cogerPrecioIndividual($id,$db){
        
        $sql ="select UnitPrice from Track where TrackId='$id' ";
        $precio=0;
        $resultado = mysqli_query($db, $sql);
        if($resultado){
            $precio=mysqli_fetch_assoc($resultado)['UnitPrice'];
            
        }
      
    return $precio;
    }
    
   function musicas($db){
        $sql ="select name from Track";
        $resultado = mysqli_query($db, $sql);
        if($resultado){
	
            while ($fila = mysqli_fetch_assoc($resultado)) {
                $musicas[] = $fila["name"];
            }
        }
        return $musicas;

   }

   function agregarcancion($db){
       $nombreM=$_POST["musica"];
    $cantida=1;
    $id=Id_cancion($db,$_POST['musica']);

   
  
   if(isset($_SESSION['carrito3'])){
        if(!array_key_exists($nombreM,$_SESSION['carrito3'])){


        $arrayValores=array($id,$cantida);
        $arrayAux=$_SESSION['carrito3'];
        $arrayAux[$nombreM]=$arrayValores;
        $_SESSION['carrito3']=$arrayAux;
      


        }else{

            $arrayAsocitivo=$_SESSION['carrito3'][$nombreM];
            $arrayAsocitivo[1]++;
            $_SESSION['carrito3'][$nombreM]= $arrayAsocitivo;
            var_dump($_SESSION['carrito3']);
        }
        echo "existe";


    }else {

        $arrayAsocitivo[$nombreM]=$arrayValores=array($id,$cantida);
        $_SESSION['carrito3']=$arrayAsocitivo;
      
        var_dump($_SESSION);
        
        
       


    }

 
  
}
   
   function musics($db){
        $sql ="select name from Track";
        $resultado = mysqli_query($db, $sql);
        if($resultado){
	
            while ($fila = mysqli_fetch_assoc($resultado)) {
                $musicas[] = $fila["name"];
            }
        }
        return $musicas;

   }

   function Id_cancion($db,$nombre){
    $id="";
 $a="\"".$nombre."\"";
 $sql ="select TrackId from Track where name=$a";
    $resultado = mysqli_query($db, $sql);
    if($resultado){
      $id = mysqli_fetch_assoc($resultado)['TrackId'];
    
      //echo "<h1>".$id;
    }
return $id;

   }
   
   ?>