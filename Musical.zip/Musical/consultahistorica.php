<html>
        
        <head>
            <title>Welcome </title>
        </head>
        <body> 
        <form action="#" method="post">
	
		<div>
        
        <input type="date" name="fechaInicio" > fechaInicio <br>
        <input type="date" name="fechafinal" > fechafinal <br>
         
			
			
			
			
			
		</div>
		<br>

		<div>
			<input type="submit" value="Limpiar la Cesta" name="limpiar">
		</div>		
	</form>      
    
      </body>

   </html>

   <?php
   function consultahistorica(){

    
   }
   
   
   ?>