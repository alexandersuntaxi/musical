<?php
  session_start();

      if(isset($_SESSION['login_user'])==false){
         echo "esta parte solo es para usuarios registrados";
      }else{

      
      
?>
<html>
   
   <head>
      <title>Welcome </title>
   </head>
   
   <body>
      <h1>Bienvenido </h1> 
	  
	  
	  <nav class="dropdownmenu">
  <ul>
    <li><a href="pe_altaped.php">Hacer Pedido</a></li>
    <li><a href="#">Mis pedidos</a>
      <ul id="submenu">
        <li><a href="pe_consped.php">Consultar Pedidos</a></li>
        <li><a href="consultarFechas.php">Consultar por fechas</a></li>      </ul>
    </li>
    <li><a href="productos.php">Listado Productos</a></li>
  
  </ul>
</nav>
	  
	  
	  
      <h2><a href = "logout.php">Cerrar Sesion</a></h2>
   </body>
   
</html>
<?php
      }
?>